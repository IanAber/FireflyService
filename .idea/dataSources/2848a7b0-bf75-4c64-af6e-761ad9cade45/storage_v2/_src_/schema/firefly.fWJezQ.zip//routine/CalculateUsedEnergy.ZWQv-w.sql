create
    definer = ian@`%` function CalculateUsedEnergy(testdate datetime) returns float
BEGIN
	declare startDate datetime(6);
	declare enddate datetime(6);
	declare minGas float;
	declare maxGas float;
	declare consumption float;

	/* find the last time of production */
	select max(logged) into startdate
	  from logging
	 where (ifnull(el0H2Flow, 0) + ifnull(el1H2Flow, 0)) > 0 and logged > date(testdate) and logged < date(date_add(testdate, interval 1 day));
	

	
	/* Find the start of production for the next day */
	select min(logged) into enddate
	  from logging
	 where (ifnull(el0H2Flow, 0) + ifnull(el1H2Flow, 0)) > 0 and logged > startdate;


	/* Find the starting pressure */
	select gasTankPressure into maxGas from logging where logged = startdate;
	/* Find the ending pressure */
	select gasTankPressure into minGas from logging where logged = enddate;
	/* Get the total NL of hydrogen produced */
	select sum(ifnull(fc0OutputPower , 0) + ifnull(fc1OutputPower , 0)) / 3600 into consumption
	  from logging
	 where logged between startdate and enddate;
	
	return round(consumption / ((maxGas - minGas) * 152));
END;

