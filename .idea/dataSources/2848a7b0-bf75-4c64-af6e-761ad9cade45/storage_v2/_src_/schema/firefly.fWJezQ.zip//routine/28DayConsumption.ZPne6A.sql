create
    definer = ian@`%` function `28DayConsumption`() returns float
BEGIN
	SET @row_index := -1;
	SELECT avg(rate) into @median_rate
	  from (
		SELECT SUM(IFNULL(fc1OutputPower, 0) + IFNULL(fc2OutputPower, 0)) / (3600) AS rate,
			   @row_index := @row_index + 1 AS row_index
  		  FROM logging
		 WHERE logged between DATE_ADD(CURRENT_DATE, interval -28 day) AND CURRENT_DATE
	     GROUP BY date(logged)) AS rates
   	 WHERE rates.row_index IN (FLOOR(@row_index / 2), CEIL(@row_index / 2));

	RETURN @median_rate;
END;

