create definer = ian@`%` view HourlyPower as
select round(unix_timestamp(min(`firefly`.`logging`.`logged`)) / 3600, 0) * 3600 AS `logged`,
       round(avg(greatest(
               ifnull(`firefly`.`logging`.`fc0OutputPower`, 0) + ifnull(`firefly`.`logging`.`fc1OutputPower`, 0), 0)) /
             1000, 2)                                                            AS `used`,
       round(avg(greatest(ifnull(`firefly`.`logging`.`el0H2Flow`, 0) + ifnull(`firefly`.`logging`.`el1H2Flow`, 0), 0)) /
             1000 * 1.209, 2)                                                    AS `stored`
from `firefly`.`logging`
group by from_unixtime(unix_timestamp(`firefly`.`logging`.`logged`) DIV 3600 * 3600);

