create
    definer = ian@`%` function PowerStage(stage int) returns varchar(25)
BEGIN
	case stage 
		when 0 then return 'OFF';
		when 1 then return 'Idle';
		when 2 then return 'H2 Purge';
		when 3 then return 'Startup';
		when 4 then return 'Air Purge';
		when 5 then return 'Leak Check';
		when 6 then return 'Manual';
		when 7 then return 'Emergency Shutdown';
		when 8 then return 'Fault';
		when 9 then return 'Shutdown';
		else return 'Unknown';
	end case;
END;

