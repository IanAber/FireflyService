create definer = ian@`%` event archive_logging on schedule
    every '1' DAY
        starts '2022-04-06 23:59:00'
    enable
    do
    BEGIN
		CALL archive_logging;
	END;

