create
    definer = ian@`%` function CalculateStoredEnergy(testdate datetime) returns float
BEGIN
	declare startDate datetime(6);
	declare enddateConsumption datetime(6);
	declare enddateProduction datetime(6);
	declare enddate datetime(6);
	declare minGas float;
	declare maxGas float;
	declare production float;

	/* find the start of production */
	select min(logged) into startdate
	  from logging
	 where (ifnull(el1H2Flow, 0) + ifnull(el2H2Flow, 0)) > 0 and logged > date(testdate) and logged < date(date_add(testdate, interval 1 day));
	
	/* Find the start of consumpton  or end of production whichever is first
	   First get the first consumption time when the fuel cells fired up. */
	select min(logged) into enddateConsumption
	  from logging
	 where (ifnull(fc1OutputPower, 0) + ifnull(fc2OutputPower, 0)) > 0 and logged > startdate;
	/* Now get ht elast recorded production time before the electrolysers stopped */
	select max(logged) into enddateProduction
	  from logging
	 where (ifnull(el1H2Flow, 0) + ifnull(el2H2Flow, 0)) > 0 and logged > date(testdate) and logged < date(date_add(testdate, interval 1 day));

	/* Out wind stops at the beginning of consumption or the end of production, whichever is first. */
	set enddate = least(enddateProduction, enddateConsumption);

	/* Find the starting pressure */
	select gasTankPressure into minGas from logging where logged = startdate;
	/* Find the ending pressure */
	select gasTankPressure into maxGas from logging where logged = enddate;
	/* Get the total NL of hydrogen produced */
	select sum(ifnull(el1H2Flow, 0) + ifnull(el2H2Flow, 0)) / 3600 into production
	  from logging
	 where logged between startdate and enddate;
	
	return round(production / (maxGas - minGas));
END;

