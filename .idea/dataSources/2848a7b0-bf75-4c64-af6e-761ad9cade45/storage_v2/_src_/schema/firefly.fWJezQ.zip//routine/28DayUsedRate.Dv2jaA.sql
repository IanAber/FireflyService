create
    definer = ian@`%` function `28DayUsedRate`() returns float
BEGIN
	SET @row_index := -1;
	select avg(rate) into @median_rate
	  from (
		select rate, @row_index := @row_index + 1 as row_index
		  from (select CalculateUsedEnergy(logged) rate, logged
		          from ( select date(min(logged)) as logged
		                   from logging
		                  where logged > date_add(current_date, interval -28 day)
		                    and logged < current_date
		                  group by date(logged)) as dates) as rates
		 where rate is not null
		 order by rate) as rate_subq
		 
	 where rate_subq.row_index in (floor(@row_index / 2), ceil(@row_index / 2));

	return @median_rate;
END;

