create definer = ian@`%` view DailyPowerArchive as
select round(unix_timestamp(min(`firefly`.`logging_archive`.`logged`)) / 86400, 0) * 86400 AS `logged`,
       round(avg(greatest(
               `firefly`.`logging_archive`.`fc0OutputPower` + ifnull(`firefly`.`logging_archive`.`fc1OutputPower`, 0),
               0)) * 24 / 1000, 2)                                                         AS `used`,
       round(avg(greatest(
               ifnull(`firefly`.`logging_archive`.`el0H2Flow`, 0) + ifnull(`firefly`.`logging_archive`.`el1H2Flow`, 0),
               0)) * 24 / 1000, 2) * 1.209                                                 AS `stored`
from `firefly`.`logging_archive`
group by cast(`firefly`.`logging_archive`.`logged` as date);

