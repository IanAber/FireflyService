create definer = ian@`%` view MiscData as
select `firefly`.`logging`.`logged`                     AS `logged`,
       `firefly`.`logging`.`gasTankPressure` / 1000     AS `gasTankPressure`,
       `firefly`.`logging`.`gasFuelCellPressure` / 10   AS `gasFuelCellPressure`,
       `firefly`.`logging`.`totalDissolvedSolids` / 100 AS `totalDissolvedSolids`,
       `firefly`.`logging`.`ACPower` / 100              AS `ACPower`,
       `firefly`.`logging`.`ACVolts` / 100              AS `ACVolts`,
       `firefly`.`logging`.`ACFrequency` / 100          AS `ACFrequency`,
       `firefly`.`logging`.`ACCurrent` / 100            AS `ACCurrent`,
       `firefly`.`logging`.`ACPowerFactor` / 100        AS `ACPowerFactor`,
       `firefly`.`logging`.`ACEnergy`                   AS `ACEnergy`,
       `firefly`.`logging`.`HPPower` / 100              AS `HPPower`,
       `firefly`.`logging`.`HPVolts` / 100              AS `HPVolts`,
       `firefly`.`logging`.`HPFrequency` / 100          AS `HPFrequency`,
       `firefly`.`logging`.`HPCurrent` / 100            AS `HPCurrent`,
       `firefly`.`logging`.`HPPowerFactor` / 100        AS `HPPowerFactor`,
       `firefly`.`logging`.`HPEnergy`                   AS `HPEnergy`
from `firefly`.`logging`;

