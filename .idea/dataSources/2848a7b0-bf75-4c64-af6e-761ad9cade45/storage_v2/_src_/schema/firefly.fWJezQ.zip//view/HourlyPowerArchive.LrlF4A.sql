create definer = ian@`%` view HourlyPowerArchive as
select round(unix_timestamp(min(`firefly`.`logging_archive`.`logged`)) / 3600, 0) * 3600          AS `logged`,
       round(avg(greatest(ifnull(`firefly`.`logging_archive`.`fc0OutputPower`, 0) +
                          ifnull(`firefly`.`logging_archive`.`fc1OutputPower`, 0), 0)) / 1000, 2) AS `used`,
       round(avg(greatest(
               ifnull(`firefly`.`logging_archive`.`el0H2Flow`, 0) + ifnull(`firefly`.`logging_archive`.`el1H2Flow`, 0),
               0)) / 1000 * 1.209, 2)                                                             AS `stored`
from `firefly`.`logging_archive`
group by from_unixtime(unix_timestamp(`firefly`.`logging_archive`.`logged`) DIV 3600 * 3600);

