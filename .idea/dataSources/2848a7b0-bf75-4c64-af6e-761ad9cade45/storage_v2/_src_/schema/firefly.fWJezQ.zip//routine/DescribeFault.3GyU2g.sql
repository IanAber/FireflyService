create
    definer = ian@`%` function DescribeFault(flagType char, flagVal int unsigned) returns text
BEGIN
	DECLARE sResult TEXT;
	SELECT GROUP_CONCAT(Description SEPARATOR '; ') INTO sResult
	  FROM firefly.FcFaultDescriptions
	 WHERE FaultType = FlagType
	   AND (Flag & flagVal) <> 0;
	
	RETURN sResult;
END;

