create
    definer = ian@`%` function DecodeFault(flagType char, flagVal int unsigned) returns varchar(4096)
BEGIN
	DECLARE sResult VARCHAR(4096);
	SELECT GROUP_CONCAT(tag SEPARATOR '; ') INTO sResult
	  FROM firefly.FcFaultDescriptions
	 WHERE FaultType = FlagType
	   AND (Flag & flagVal) <> 0;
	IF (sResult IS NULL) THEN
		SET sResult = '';
	END IF;
/*	IF (sResult IS NULL) THEN
	  SET sResult = CONCAT('Unknown ', flagVal);
	END IF; */
	RETURN sResult;
END;

