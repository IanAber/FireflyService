create definer = ian@`%` view MonthlyPowerArchive as
select round(unix_timestamp(min(`firefly`.`logging_archive`.`logged`)) / 86400, 0) * 86400 AS `logged`,
       round(avg(greatest(`firefly`.`logging_archive`.`fc0OutputPower` +
                          ifnull(`firefly`.`logging_archive`.`fc1OutputPower`, 0), 0)) * 24 *
             (timestampdiff(DAY, min(`firefly`.`logging_archive`.`logged`), max(`firefly`.`logging_archive`.`logged`)) +
              1) / 1000, 2)                                                                AS `used`,
       round(avg(greatest(ifnull(`firefly`.`logging_archive`.`el0H2Flow`, 0) +
                          ifnull(`firefly`.`logging_archive`.`el1H2Flow`, 0), 0)) * 24 *
             (timestampdiff(DAY, min(`firefly`.`logging_archive`.`logged`), max(`firefly`.`logging_archive`.`logged`)) +
              1) / 1000 * 1.209, 2)                                                        AS `stored`
from `firefly`.`logging_archive`
group by month(`firefly`.`logging_archive`.`logged`), year(`firefly`.`logging_archive`.`logged`);

