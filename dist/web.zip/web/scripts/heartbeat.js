var wstimeout;

function StartHeartbeat() {
    if ($("#heartbeat").length < 1) {
        $("#system").after('<img class="heartbeat" id="heartbeat" src="images/heartbeat.png" />')
    }
    heartbeat = $("#heartbeat");
    $("#heartbeat").css({width: "20px", height: "20px"})
    $("#heartbeat").animate({width: "15px", height: "15px"})

    // Clear the timeout timer if it is active
    if (wstimeout !== 0) {
        clearTimeout(wstimeout);
    }
    wstimeout = setTimeout(RegisterWebSocket, 5000)
}
